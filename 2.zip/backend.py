import backend_config
from functions import mongo_functions as mongo
from functions import text_preparation

from flask import Flask, request, render_template, Response
import json

import pickle
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import re

db = mongo.DB(ip='127.0.0.1', port=27017, database='db')

with open('assets/pickled_data/features.pickle', 'rb') as f:
    features = pickle.load(f)
with open('assets/pickled_data/tfidf.pickle', 'rb') as f:
    tfidf = pickle.load(f)
with open('assets/pickled_data/docs_order.pickle', 'rb') as f:
    files = pickle.load(f)

FILES_COUNT = len(files)
files_dict = dict()

for file in files:
    with open('assets/pickled_data/{}.pickle'.format(file.replace('docx', '')), 'rb') as f:
        data = pickle.load(f)
    files_dict[file] = data

text_half_size = 15


norm_text = lambda x : re.sub(r'[;/)(?!\.:,""«»\s]', ' ', x).lower()


def text_search(query, array, word_index_dict):
    query = query.split()
    query_norm = []
    for q in query:
        query_norm.append(norm_text(q))
    
    result = []

    for ind, q in enumerate(query_norm):
        word = query_norm[ind]

        if word in word_index_dict:
            for index in word_index_dict[word]:
                indexes = []
                indexes.append(index)
                for ind2 in range(1, len(query_norm)):
                    
                    word2 = norm_text(array[index + ind2]) 
                    if word2 == query_norm[ind2]:
                        indexes.append(index + ind2)

                if len(indexes) == len(query_norm):
                    result.append([' '.join(array[indexes[0] - text_half_size : indexes[0]]),
                                   ' '.join(array[indexes[0] : indexes[-1] + 1]),
                                   ' '.join(array[indexes[-1] + 1 : indexes[-1] + text_half_size])])
  
    return result


def top_k(arr, k):
    kth_largest = (k + 1) * -1
    return np.argsort(arr)[:kth_largest:-1]


app = Flask(__name__)

@app.route('/get_db', methods=['POST'])
def get_db():
    if request.method == 'POST':
        print(request.get_json())
        named_entities = request.get_json()

        print(named_entities)
        
        answer_field = ["public_name", 'document_path', 'Themes']

        data = db.find(theme='Sahalin',
                       named_entities=named_entities,
                       answer_field=answer_field)

        if 'Themes' in named_entities:
            for ind, element in enumerate(data):
                with open('assets/themes_files/{}'.format(element['document_path'].split('/')[-1].replace('html', 'json')), 'r') as f:
                    d = json.load(f)
                element['texts'] = d[named_entities['Themes']]

        return data


@app.route('/get_tfidf', methods=['POST'])
def get_tfidf():
    if request.method == 'POST':
        print(request.get_json())
        
        query_origin = request.get_json()['query']
        query = [' '.join(text_preparation.norm_preprocess(query_origin))]

        query_tfidf = tfidf.transform(query)

        cosine_similarities = cosine_similarity(features, query_tfidf).flatten()

        top_related_indices = top_k(cosine_similarities, FILES_COUNT)
        
        data = dict()
        named_entities = {'document_name' : []}
        named_entities2 = request.get_json()
        named_entities2.pop('query')
        for i in top_related_indices:
            if cosine_similarities[i] > 0:
                data[files[i]] = cosine_similarities[i]
                named_entities['document_name'].append(files[i])

        answer_field = ["public_name", 'document_path', 'Themes']

        if len(named_entities['document_name']) > 0:
            data = db.find2(theme='Sahalin',
                           named_entities=named_entities,
                           named_entities2=named_entities2,
                           answer_field=answer_field)

            final_data = []
            for ind, element in enumerate(data):
                array, word_index_dict = files_dict[element['document_path'].split('/')[-1].replace('html', 'docx')]                

                texts = text_search(query_origin, array, word_index_dict)
                if len(texts) > 0:
                    final_data.append(element)
                    final_data[-1]['texts'] = texts
                
            data = final_data            
        else:
            data = {}

        return data


if __name__ == "__main__":
    app.run(host=backend_config.IP,
            port=backend_config.PORT,
            debug=True)
