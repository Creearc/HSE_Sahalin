import frontend_config

from dash import Dash, dcc, html
from dash.dependencies import Input, Output, State
import base64
import os
import requests


names = ['Бородин Вадим Анатольевич',
         'Артамонов Виктор Сергеевич',
         'Петр Игнатьевич',
         'Поманисточка Александр Иванович',
         'Федосов Валерий Николаевич',
         ]
years = [1944,
         1951,
         1964,
         1969,
         ]

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = Dash(__name__, external_stylesheets=external_stylesheets)

app.layout = html.Div([
    html.Center([
        html.H3('АНТРОПОЛОГИЯ ТРУДА', style={"font-weight": "bold"}),
    html.Table([
        html.Tr([
            html.Th(html.P('Поиск')),
            html.Th(dcc.Input(id='input_phrase', type='text', value='', style={'width':'90%'}))
            ]),
        ], style={'width':'50%'}),

    html.Button(id='show-btn', n_clicks=0, children='Продвинутый поиск', style={'align':"left"}),

    html.Div(id='hidden-elements', style={'display': 'none'}, children=[
    html.Table([
        html.Tr([
            html.Th(html.P('ФИО'), style={'width':'10%'}),
            html.Th(dcc.Dropdown(names, None, id='input_name',
                 maxHeight=300, optionHeight=50), style={'width':'40%'}),

            html.Th(html.P('Пол'), style={'width':'10%'}),
            html.Th(dcc.Dropdown(['м', 'ж'], None, id='sex_dropdown',
                 maxHeight=300, optionHeight=50), style={'width':'40%'})
            ]),

        html.Tr([
            html.Th(html.P('Год рождения')),
            html.Th(dcc.Dropdown(years, None, id='input_birth_year',
                 maxHeight=300, optionHeight=50), style={'width':'40%'}),

            html.Th(html.P('Профессия')),
            html.Th(dcc.Dropdown(['шахтер', 'работник лесной промышленности', 'преподаватель вуза', 'строитель'], None, id='job_dropdown',
                 maxHeight=300, optionHeight=50), style={'width':'40%'})
            ]),

        html.Tr([
            html.Th(html.P('Источник')),
            html.Th(dcc.Dropdown(['интервью', 'песня', 'сказка'], None, id='source_type_dropdown',
                 maxHeight=300, optionHeight=50), style={'width':'40%'}),

            html.Th(html.P('Тема')),
            html.Th(dcc.Dropdown(frontend_config.THEMES_LIST, None, id='theme_dropdown',
                 maxHeight=300, optionHeight=50), style={'width':'40%'})
            ]),
        
        ], style={'width':'50%'}),
    ]),
    
    html.Button(id='submit-button-state', n_clicks=0, children='Искать'),
    ]),
    
    html.Div(id='output-state'),
    
])


@app.callback(
    Output('hidden-elements', 'style'),
    Input('show-btn', 'n_clicks')
)
def show_hidden_elements(n_clicks):
    if n_clicks % 2 == 0:
        return {'display': 'none'}
    else:
        return {'display': 'block'}


@app.callback(Output('output-state', 'children'),
              Input('submit-button-state', 'n_clicks'),
              State('input_phrase', 'value'),
              State('input_name', 'value'),
              State('input_birth_year', 'value'),
              State('sex_dropdown', 'value'),
              State('job_dropdown', 'value'),
              State('source_type_dropdown', 'value'),
              State('theme_dropdown', 'value'),
              )
def update_output(n_clicks, input_phrase, input_name,
                  input_birth_year, sex_dropdown,
                  job_dropdown, source_type_dropdown, theme_dropdown):
     
    request_data = dict()
    data = None
    links = 'Ничего не найдено'
    count = 0

    if input_name != '' and not(input_name is None):
        input_name = input_name.split()
        if len(input_name) == 3:
            request_data['Name'] = input_name[1]
            request_data['Second_name'] = input_name[0]
            request_data['Third_name'] = input_name[2]
        elif len(input_name) == 2:
            request_data['Name'] = input_name[0]
            request_data['Third_name'] = input_name[1]
            
    if not (input_birth_year is None): request_data['Birth_year'] = input_birth_year
    if not (sex_dropdown is None): request_data['Sex'] = sex_dropdown
    if not (job_dropdown is None): request_data['Job'] = job_dropdown
    if not (source_type_dropdown is None): request_data['Source_type'] = source_type_dropdown 

    if input_phrase != '':
        url = 'http://{}:{}/get_tfidf'.format(frontend_config.BACKEND_IP, frontend_config.BACKEND_PORT)
        request_data['query'] = input_phrase
        if len(request_data) > 0:
            data = requests.post(url, json = request_data)

    else:
        url = 'http://{}:{}/get_db'.format(frontend_config.BACKEND_IP, frontend_config.BACKEND_PORT)
        if not (theme_dropdown is None): request_data['Themes'] = theme_dropdown.split()[0] 

        if len(request_data) > 0:
            data = requests.post(url, json = request_data)

    if not (data is None):
        data = data.json()
        if len(data) > 0:
            links = []

            for element in data:
                tmp_texts = []
                if 'texts' in element:
                    if 'Themes' in request_data:
                        for text in element['texts']:
                            tmp_texts.append(html.P(text))

                    else:
                        for text in element['texts']:
                            tmp_texts.append(html.P(html.Div([text[0], ' ', html.B(text[1]), ' ', text[2]])))
                    
                links.append(html.Div([html.P(html.A(element['public_name'], href=element['document_path'], target="_blank")),
                            html.Div(tmp_texts)]))

            count = len(links)
           
    return html.Div([
      html.Hr(),
      html.H3('Результаты поиска'),
      html.P('Количество найденных документов: {}'.format(count)),
      html.Div(links),
      html.Hr(),
      ])


if __name__ == '__main__':
    app.run_server(host=frontend_config.IP, port=frontend_config.PORT, debug=True)
