from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os
import numpy as np

import docx2txt

import pymorphy2
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer

import re

import pickle


def punktuation_preprocess(text):  
    text1 = re.sub(r'[;/)(?!\.:,""«»\s]', ' ', text) 
    tokens = word_tokenize(text1) 
    tokens = [word.lower() for word in tokens] 
    return tokens

def norm_preprocess(text, morph):
    tokens = punktuation_preprocess(text)
    #tokens = [word for word in tokens if word.isalpha()]  # Remove the punctuations
    tokens = [word.lower() for word in tokens]
    words=[]
    for word in tokens:
        p = morph.parse(word)[0]
        words.append(p.normal_form)
    return words

    
def top_k(arr, k):
    kth_largest = (k + 1) * -1
    return np.argsort(arr)[:kth_largest:-1]


def extract_text_data(data):
    array = data.split()

    word_index_dict = dict()

    for index, element in enumerate(array):
        word = re.sub(r'[;/)(?!\.:,""«»\s]', ' ', element).lower()

        if len(word) == 0:
            continue
        
        if word in word_index_dict:
            word_index_dict[word].append(index)
        else:
            word_index_dict[word] = [index]

    return array, word_index_dict
    

def run(path='data/1', output_path=''):
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    tfidf = TfidfVectorizer()
    morph = pymorphy2.MorphAnalyzer()

    data = []
    files = os.listdir(path)
    for file in files:
        text = docx2txt.process('{}/{}'.format(path, file))

        array, d = extract_text_data(text)
        with open('{}/{}.pickle'.format(output_path, file.replace('docx', '')), 'wb') as f:
            pickle.dump([array, d], f)

        data.append(text)
        print('{}/{}'.format(len(data), len(files)))
        
    features = tfidf.fit_transform(data)
    
    with open('{}/features.pickle'.format(output_path), 'wb') as f:
        pickle.dump(features, f)
    with open('{}/tfidf.pickle'.format(output_path), 'wb') as f:
        pickle.dump(tfidf, f)
    with open('{}/docs_order.pickle'.format(output_path), 'wb') as f:
        pickle.dump(files, f)


if __name__ == '__main__':
    run('../data/texts/3', '../assets/pickled_data')
