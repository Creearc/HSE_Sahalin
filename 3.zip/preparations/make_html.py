import os
import docx2txt

template = '''
<html>
  <head>
    <title>{}</title>
  </head>
  <body>
    <p>
    {}
    </p>
  </body>
</html>
'''

def replace_themes_marks(text):
    result = []
    for word in text.split():
        if '[' in word or ']' in word:
            word = word.replace('[', '').replace(']', '')
            try:
                word = float(word)
                continue
            except:
                pass

        result.append(word)
            
    return ' '.join(result)


def run(path='data/1', output_path=''):
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    files = os.listdir(path)
    for file in files:
        text = docx2txt.process('{}/{}'.format(path, file))

        text = text.replace('\n', '</p><p>').replace('<p></p><p></p>', '<br>')
        text = replace_themes_marks(text)
        
        name = file[:-len('.docx')]
        with open('{}/{}.html'.format(output_path, name), 'w') as f:
            f.write(template.format(name, text))


if __name__ == '__main__':
    run('../data/texts/4', '../assets/pages')
