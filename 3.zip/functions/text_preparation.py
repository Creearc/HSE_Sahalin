import pymorphy2
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer

import re

morph = pymorphy2.MorphAnalyzer()
stemmer = SnowballStemmer("russian")
stop_words = stopwords.words("russian")

def punktuation_preprocess(text):  # puctuation filtering and lower case
    text1 = re.sub(r'[;/)(?!\.:,""«»\s]', ' ', text) # Remove the punctuations
    tokens = word_tokenize(text1)  # tokenization
    tokens = [word.lower() for word in tokens]  #make lower case
    return tokens

def stemm_preprocess(text):  # stemming
    tokens = word_tokenize(text)  # tokenization
    tokens = [word for word in tokens if word.isalpha()]  # Remove the punctuations
    tokens = [word.lower() for word in tokens if not word in stop_words]  # Remove stopword and make lower case
    tokens = [stemmer.stem(word) for word in tokens]  # stemming
    return tokens

def norm_preprocess(text):  # normalization with morphanalizer
    tokens = punktuation_preprocess(text)
    #tokens = word_tokenize(text)  # tokenization
    #tokens = [word for word in tokens if word.isalpha()]  # Remove the punctuations
    tokens = [word.lower() for word in tokens]  # Remove stopword and make lower case
    words=[]
    for word in tokens:
        p = morph.parse(word)[0]  # normal form
        words.append(p.normal_form)
    return words
