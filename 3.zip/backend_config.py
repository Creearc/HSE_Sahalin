# Python code

IP = '127.0.0.1'
PORT = 8090
