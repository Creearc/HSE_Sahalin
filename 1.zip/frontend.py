import frontend_config

from dash import Dash, dcc, html
from dash.dependencies import Input, Output, State
import base64
import os
import requests


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = Dash(__name__, external_stylesheets=external_stylesheets)

app.layout = html.Div([
    html.Center([
        html.H3('АНТРОПОЛОГИЯ ТРУДА', style={"font-weight": "bold"}),
    html.Table([
        html.Tr([
            html.Th(html.P('Поиск')),
            html.Th(dcc.Input(id='input_phrase', type='text', value='', style={'width':'90%'}))
            ]),
        ], style={'width':'50%'}),
        
    html.Table([ 
        html.Tr([
            html.Th(html.P('Имя'), style={'width':'10%'}),
            html.Th(dcc.Input(id='input_name', type='text', value=''), style={'width':'40%'}),

            html.Th(html.P('Фамилия'), style={'width':'10%'}),
            html.Th(dcc.Input(id='input_2name', type='text', value=''), style={'width':'40%'})
            ]),

        html.Tr([
            html.Th(html.P('Отчество'), style={'width':'10%'}),
            html.Th(dcc.Input(id='input_3name', type='text', value=''), style={'width':'40%'}),

            html.Th(html.P('Пол'), style={'width':'10%'}),
            html.Th(dcc.Dropdown(['м', 'ж'], None, id='sex_dropdown',
                 maxHeight=300, optionHeight=50), style={'width':'40%'})
            ]),

        html.Tr([
            html.Th(html.P('Год рождения')),
            html.Th(dcc.Input(id='input_birth_year', type='number', value=None,
                              min=1900, max=2023)),

            html.Th(html.P('Профессия')),
            html.Th(dcc.Dropdown(['шахтер', 'повар', 'строитель'], None, id='job_dropdown',
                 maxHeight=300, optionHeight=50), style={'width':'40%'})
            ]),

        html.Tr([
            html.Th(html.P('Источник')),
            html.Th(dcc.Dropdown(['интервью', 'песня', 'сказка'], None, id='source_type_dropdown',
                 maxHeight=300, optionHeight=50), style={'width':'40%'}),

            html.Th(html.P('Тема')),
            html.Th(dcc.Dropdown(frontend_config.THEMES_LIST, None, id='theme_dropdown',
                 maxHeight=300, optionHeight=50), style={'width':'40%'})
            ]),
        
        ], style={'width':'50%'}),
    
    html.Button(id='submit-button-state', n_clicks=0, children='Искать'),
    ]),
    
    html.Div(id='output-state'),
    
])


@app.callback(Output('output-state', 'children'),
              Input('submit-button-state', 'n_clicks'),
              State('input_phrase', 'value'),
              State('input_name', 'value'),
              State('input_2name', 'value'),
              State('input_3name', 'value'),
              State('input_birth_year', 'value'),
              State('sex_dropdown', 'value'),
              State('job_dropdown', 'value'),
              State('source_type_dropdown', 'value'),
              State('theme_dropdown', 'value'),
              )
def update_output(n_clicks, input_phrase, input_name, input_2name, input_3name,
                  input_birth_year, sex_dropdown,
                  job_dropdown, source_type_dropdown, theme_dropdown):
    
    
    request_data = dict()
    data = None
    links = 'Ничего не найдено'
    count = 0

    if input_phrase != '':
        url = 'http://{}:{}/get_tfidf'.format(frontend_config.BACKEND_IP, frontend_config.BACKEND_PORT)
        request_data['query'] = input_phrase
        if len(request_data) > 0:
            data = requests.post(url, json = request_data)

    else:
        url = 'http://{}:{}/get_db'.format(frontend_config.BACKEND_IP, frontend_config.BACKEND_PORT)
        if input_name != '': request_data['Name'] = input_name
        if input_2name != '': request_data['Second_name'] = input_2name
        if input_3name != '': request_data['Third_name'] = input_3name
        if not (input_birth_year is None): request_data['Birth_year'] = input_birth_year
        if not (sex_dropdown is None): request_data['Sex'] = sex_dropdown
        if not (job_dropdown is None): request_data['Job'] = job_dropdown
        if not (source_type_dropdown is None): request_data['Source_type'] = source_type_dropdown
        if not (theme_dropdown is None): request_data['Themes'] = theme_dropdown.split()[0]  

        if len(request_data) > 0:
            data = requests.post(url, json = request_data)

    if not (data is None):
        data = data.json()
        if len(data) > 0:
            links = [html.P(html.A(element['public_name'], href=element['document_path'], target="_blank")) for element in data]
            count = len(links)
           
    return html.Div([
      html.Hr(),
      html.H3('Результаты поиска'),
      html.P('Количество найденных документов: {}'.format(count)),
      html.Div(links),
      html.Hr(),
      ])


if __name__ == '__main__':
    app.run_server(host=frontend_config.IP, port=frontend_config.PORT, debug=True)
