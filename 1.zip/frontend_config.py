import json

IP = '0.0.0.0'
PORT = 8050

BACKEND_IP = '127.0.0.1'
BACKEND_PORT = 8090

THEMES_CONFIG = 'assets/themes.json'

with open(THEMES_CONFIG, 'r') as f:
    themes_dict = json.load(f)

THEMES_LIST = ['{} {}'.format(key, value) for key, value in themes_dict.items()]


