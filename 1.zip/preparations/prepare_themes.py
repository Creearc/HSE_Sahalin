import os

# pip install docx2txt
import docx2txt
import json

PATH = '../data/texts/3'
THEMES_PATH = '../data/themes/1/Темник.docx'

THEMES_OUTPUT = '../assets/themes.json'
THEMES_FILES_OUTPUT_PATH = '../assets/themes_files'

themes_dict = dict()

text = docx2txt.process(THEMES_PATH)
lines = text.split('\n')
for line in lines:
    s = line.strip().split()
    if len(s) <= 1:
        continue

    if s[0][0].isnumeric():
        themes_dict[s[0][:-1]] = ' '.join(s[1:])


if not os.path.exists(THEMES_FILES_OUTPUT_PATH):
    os.makedirs(THEMES_FILES_OUTPUT_PATH)
        
with open(THEMES_OUTPUT, 'w', encoding='utf-8') as f:
    f.write(json.dumps(themes_dict))


for file in os.listdir(PATH):
    if not('ТВ.docx' in file):
        continue
    text = docx2txt.process('{}/{}'.format(PATH, file))

    text_themes = dict()
    tmp_themes = dict()
    text_parts = text.split()

    for part in text_parts:
        if part[-1] == '[':
            tmp_themes[part[:-1]] = []
        elif part[0] == ']':
            key = part[1:]
            try:
                value = ' '.join(tmp_themes[key])
            except:
                print(file, key)
                continue
            
            if key in text_themes:
                text_themes[key].append(value)
            else:
                text_themes[key] = [value]              
            tmp_themes.pop(key)
            
        else:
            for key in tmp_themes:
                tmp_themes[key].append(part)

    with open('{}/{}.json'.format(THEMES_FILES_OUTPUT_PATH, file[:-len('.docx')]), 'w', encoding='utf-8') as f:
        f.write(json.dumps(text_themes))

    

