import os
import docx2txt

template = '''
<html>
  <head>
    <title>{}</title>
  </head>
  <body>
    <p>
    {}
    </p>
  </body>
</html>
'''


def run(path='data/1', output_path=''):
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    files = os.listdir(path)
    for file in files:
        text = docx2txt.process('{}/{}'.format(path, file))

        text = text.replace('\n', '</p><p>').replace('<p></p><p></p>', '<br>')
        
        name = file[:-len('.docx')]
        with open('{}/{}.html'.format(output_path, name), 'w') as f:
            f.write(template.format(name, text))


if __name__ == '__main__':
    run('../data/texts/3', '../assets/pages')
