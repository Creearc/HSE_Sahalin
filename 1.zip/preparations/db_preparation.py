import json
import sys

path = '/'.join(sys.path[0].replace('\\', '/').split('/')[:-1])
print(path)
sys.path.insert(0, path)

from functions import mongo_functions as mongo

document_info = {"public_name" : '',
                 "document_name" : '',
                 "document_path" : '',
                 "tfidf_path" : '',
                 "themes_path" : '',
                 "Name" : '',
                 "Second_name" : '',
                 "Third_name" : '',
                 "Job" : '',
                 "Sex" : '',
                 "Birth_year" : 1234,
                 "Themes" : [],
                 "Source_type" : '',
                 "Source_date" : ''
                 }
                 

def check_fields_types(template, data):
    error = False
    print('[START] check_fields_types')
    for element in data:
        public_name = element["public_name"]

        for key in template:
            if not(key in element):
                print('Key error!')
                print('{} -> {}'.format(public_name, key))
                error = True

            else:
                if type(template[key]) != type(element[key]):
                    print('Value type error!')
                    print('{} -> {}'.format(public_name, key))
                    error = True
                    
    print('[END] check_fields_types')
    return not error


def add_themes_info(data):
    for element in data:
        themes_path = element["themes_path"]

        with open(themes_path, 'r') as f:
            themes_dict = json.load(f)

        themes = [key for key in themes_dict.keys()]
        element["Themes"] = themes

    return data
        
    

if __name__ == '__main__':
    arr = []
    arr.append({"public_name" : 'Бородин Вадим Анатольевич',
                "document_name" : 'Бородин (1) ТВ.docx',
                 "document_path" : '/assets/pages/Бородин (1) ТВ.html',
                 "tfidf_path" : '',                
                 "themes_path" : '../assets/themes_files/Бородин (1) ТВ.json',
                 "Name" : 'Вадим',
                 "Second_name" : 'Бородин',
                 "Third_name" : 'Анатольевич',
                 "Job" : 'шахтер',
                 "Sex" : 'м',
                 "Birth_year" : 1969,
                 "Themes" : [],
                 "Source_type" : 'интервью',
                 "Source_date" : '19.09.2022'
                 })

    arr.append({"public_name" : 'Артамонов Виктор Сергеевич',
                "document_name" : 'Артамонов (1) ТВ.docx',
                 "document_path" : '/assets/pages/Артамонов (1) ТВ.html',
                 "tfidf_path" : '',                
                 "themes_path" : '../assets/themes_files/Артамонов (1) ТВ.json',
                 "Name" : 'Виктор',
                 "Second_name" : 'Артамонов',
                 "Third_name" : 'Сергеевич',
                 "Job" : 'шахтер',
                 "Sex" : 'м',
                 "Birth_year" : 0,
                 "Themes" : [],
                 "Source_type" : 'интервью',
                 "Source_date" : '20.09.2022'
                 })

    arr.append({"public_name" : 'Петр Игнатьевич',
                "document_name" : 'Петр Игнатьевич (1) ТВ.docx',
                 "document_path" : '/assets/pages/Петр Игнатьевич (1) ТВ.html',
                 "tfidf_path" : '',                
                 "themes_path" : '../assets/themes_files/Петр Игнатьевич (1) ТВ.json',
                 "Name" : 'Петр',
                 "Second_name" : '',
                 "Third_name" : 'Игнатьевич',
                 "Job" : 'шахтер',
                 "Sex" : 'м',
                 "Birth_year" : 1951,
                 "Themes" : [],
                 "Source_type" : 'интервью',
                 "Source_date" : ''
                 })

    arr.append({"public_name" : 'Поманисточка Александр Иванович',
                "document_name" : 'Поманисточка (1) ТВ.docx',
                 "document_path" : '/assets/pages/Поманисточка (1) ТВ.html',
                 "tfidf_path" : '',                
                 "themes_path" : '../assets/themes_files/Поманисточка (1) ТВ.json',
                 "Name" : 'Александр',
                 "Second_name" : 'Поманисточка',
                 "Third_name" : 'Иванович',
                 "Job" : 'шахтер',
                 "Sex" : 'м',
                 "Birth_year" : 1964,
                 "Themes" : [],
                 "Source_type" : 'интервью',
                 "Source_date" : '22.09.2022'
                 })

    arr.append({"public_name" : 'Федосов Валерий Николаевич',
                 "document_name" : 'Федосов Валерий Николаевич (1) ТВ.docx',
                 "document_path" : '/assets/pages/Федосов Валерий Николаевич (1) ТВ.html',
                 "tfidf_path" : '',                
                 "themes_path" : '../assets/themes_files/Федосов Валерий Николаевич (1) ТВ.json',
                 "Name" : 'Валерий',
                 "Second_name" : 'Федосов',
                 "Third_name" : 'Николаевич',
                 "Job" : 'шахтер',
                 "Sex" : 'м',
                 "Birth_year" : 1944,
                 "Themes" : [],
                 "Source_type" : 'интервью',
                 "Source_date" : '23.09.2022'
                 })
    
    if check_fields_types(document_info, arr):

        add_themes_info(arr)

        db = mongo.DB(ip='127.0.0.1', port=27017, database='db')

        
        db.clear('Sahalin')

        for i in arr:
            db.add(theme='Sahalin', element=i)

        db.show('Sahalin')
        
