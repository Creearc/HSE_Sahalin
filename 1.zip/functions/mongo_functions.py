"""
Set of function and class for work whit MongoDB
"""

from pymongo import MongoClient
from pprint import pprint

class DB:
  def __init__(self, ip='127.0.0.1', port=27017, database='robot'):
    self.client = MongoClient( 'mongodb://{}:{}/'.format(ip, port))
    self.knowledge_base = self.client[database]

  def add(self, theme, element):
    result = self.knowledge_base[theme].insert_one(element)
    return result.inserted_id

  def delete(self, theme, element):
    self.knowledge_base[theme].delete_one(element)

  def show(self, theme):
    for obj in list(self.knowledge_base[theme].find({})):
      print(obj)

  def clear(self, theme):
    for obj in list(self.knowledge_base[theme].find({})):
      self.delete(theme=theme, element=obj)

  def find_old(self, theme, named_entities, answer_field):
    tmp = answer_field
    answer_field = dict()
    for element in tmp:
      answer_field[element] = 1
    answer_field['_id'] = 0
    result = list(self.knowledge_base[theme].find(named_entities, answer_field))
    return result

  def find(self, theme, named_entities, answer_field, named_entities_method='$and'):
    tmp = answer_field
    answer_field = dict()
    for element in tmp:
      answer_field[element] = 1
    answer_field['_id'] = 0
    
    out = []
    if named_entities != {}:
      for key in named_entities.keys():
        if isinstance(named_entities[key], list):
          for element in named_entities[key]:
            out.append({key : element})
        else:
          out.append({key : named_entities[key]})

      named_entities = {named_entities_method : out}
    
    result = list(self.knowledge_base[theme].find(named_entities, answer_field))
    return result
