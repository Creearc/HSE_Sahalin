import backend_config
from functions import mongo_functions as mongo
from functions import text_preparation

from flask import Flask, request, render_template, Response
import json

import pickle
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

db = mongo.DB(ip='127.0.0.1', port=27017, database='db')

with open('assets/pickled_data/features.pickle', 'rb') as f:
    features = pickle.load(f)
with open('assets/pickled_data/tfidf.pickle', 'rb') as f:
    tfidf = pickle.load(f)
with open('assets/pickled_data/docs_order.pickle', 'rb') as f:
    files = pickle.load(f)

FILES_COUNT = len(files)

def top_k(arr, k):
    kth_largest = (k + 1) * -1
    return np.argsort(arr)[:kth_largest:-1]


app = Flask(__name__)

@app.route('/get_db', methods=['POST'])
def get_db():
    if request.method == 'POST':
        print(request.get_json())
        named_entities = request.get_json()

        print(named_entities)
        
        answer_field = ["public_name", 'document_path', 'Themes']

        data = db.find(theme='Sahalin',
                       named_entities=named_entities,
                       answer_field=answer_field)

        return data


@app.route('/get_tfidf', methods=['POST'])
def get_tfidf():
    if request.method == 'POST':
        print(request.get_json())
        
        query = request.get_json()['query']
        querry = [' '.join(text_preparation.norm_preprocess(query))]

        query_tfidf = tfidf.transform(querry)

        cosine_similarities = cosine_similarity(features, query_tfidf).flatten()

        top_related_indices = top_k(cosine_similarities, FILES_COUNT)
        
        data = dict()
        named_entities = {'document_name' : []}
        for i in top_related_indices:
            if cosine_similarities[i] > 0:
                data[files[i]] = cosine_similarities[i]
                named_entities['document_name'].append(files[i])

        answer_field = ["public_name", 'document_path', 'Themes']

        if len(named_entities['document_name']) > 0:
            data = db.find(theme='Sahalin',
                           named_entities=named_entities,
                           named_entities_method='$or',
                           answer_field=answer_field)
        else:
            data = {}

        return data


if __name__ == "__main__":
    app.run(host=backend_config.IP,
            port=backend_config.PORT,
            debug=True)
